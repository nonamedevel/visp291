const data = `[
    {
        "id": 1,
        "title": "Монитор ABC",
        "price": 4000
    },
    {
        "id": 2,
        "title": "Монитор XYZ",
        "price": 6000
    },
    {
        "id": 3,
        "title": "Клавиатура",
        "price": 500
    },
    {
        "id": 4,
        "title": "Системный блок",
        "price": 15000
    }
]`

// for (const item of data) {
//     console.log(item)
// }

const arr = JSON.parse(data)
// console.log(arr)

// for (const item of arr) {
//     console.log(item)
// }

/*
    How many monitors do we have?
*/
function countProducts(productName) {
    let counter = 0
    for (const item of arr) {
        if (item.title.startsWith(productName)) {
            counter++
        }
    }
    return counter
}

// console.log(countProducts('Монитор'))
// console.log(countProducts('Мышка'))

/*
    Print the name and price of the cheapest monitor
*/
function findCheapestMonitor() {
    let monitor
    for (const item of arr) {
        if (item.title.startsWith('Монитор')) {
            if (monitor) {
                if (item.price < monitor.price) {
                    monitor = item
                }
            } else {
                monitor = item
            }
        }
    }
    return monitor
}
console.log(findCheapestMonitor())
