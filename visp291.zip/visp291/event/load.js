// window.addEventListener('load', function() {
//     const button = document.querySelector('.click_me')
//     button.addEventListener('click', function() {
//         button.textContent += '!'
//     })
// })

window.onload = function() {
    const button = document.querySelector('.click_me')
    button.onclick = function() {
        button.textContent += '!'
    }
}
