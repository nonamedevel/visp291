function test() {
    console.log('for loop')
    for (let i = 0; i < 5; i++) {
        console.log(i)
    }
}

function test1() {
    console.log('while loop')
    let i = 0
    while (i < 5) {
        console.log(i)
        i++
    }
}

/*
    Infinite loop - be careful!
*/
function test1() {
    while (true) {
        console.log(123)
    }
}

test()
