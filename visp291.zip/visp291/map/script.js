function test1() {
    const map = new Map()
    console.log(map)
    console.log(map.size)

    map.set('keyboard', 'клавиатура')
    map.set('mouse', 'мышь')
    map.set('webcamera', 'вебкамера')
    map.set('processor', 'процессор')
    console.log(map)
    console.log(map.size)
}

function test1() {
    const data = [
        ['keyboard', 'клавиатура'],
        ['mouse', 'мышь'],
        ['webcamera', 'вебкамера'],
        ['processor', 'процессор'],
    ]
    const map = new Map(data)
    console.log(map)
    console.log(map.size)
}

function test1() {
    const data = [
        ['keyboard', 'клавиатура'],
        ['mouse', 'мышь'],
        ['webcamera', 'вебкамера'],
        ['processor', 'процессор'],
    ]
    const map = new Map(data)

    // for (const item of map) {
    //     console.log(item)
    // }

    // for (const [key, val] of map) {
    //     console.log(key, val)
    // }

    // for (const [key] of map) {
    //     console.log(key)
    // }

    // for (const [_, val] of map) {
    //     console.log(val)
    // }

    // for (const key of map.keys()) {
    //     console.log(key)
    // }

    // for (const val of map.values()) {
    //     console.log(val)
    // }

    for (const item of map.entries()) {
        console.log(item)
    }
}

function test() {
    const data = [
        ['keyboard', 'клавиатура'],
        ['mouse', 'мышь'],
        ['webcamera', 'вебкамера'],
        ['processor', 'процессор'],
    ]
    const map = new Map(data)

    // console.log(map.has('mouse'))
    // console.log(map.has('monitor'))
    
    // console.log(map.get('mouse'))
    // console.log(map.get('monitor'))
    
    // console.log(!!map.get('mouse'))
    // console.log(!!map.get('monitor'))
    
    // console.log(Boolean(map.get('mouse')))
    // console.log(Boolean(map.get('monitor')))

    if (map.get('mouse')) {
        console.log(123)
    } else {
        console.log(456)
    }
}

test()
