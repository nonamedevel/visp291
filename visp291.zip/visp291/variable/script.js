function test1() {
    user = 'Vasya' // not recommended
    // var user = 'Vasya'
    // let user = 'Vasya'
    // const user = 'Vasya'
    user = 'Masha'
    console.log(user)
}

function test() {
    var user = 'Vasya'
    // let user = 'Vasya'
    // const user = 'Vasya'
    console.log(user)
    var user = 'Masha'
    // let user = 'Masha'
    // const user = 'Masha'
    console.log(user)
}

test()
