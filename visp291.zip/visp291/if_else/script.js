function test1() {
    // const userName = 'Vasya'
    const userName = 'nnnnnnnnnnnnnnnnnnnnnnnn'

    if (userName.length > 15) {
        console.log('User name is too long!')
    }
}

function test() {
    // const num = 123
    const num = 5

    if (num > 1000) {
        console.log('Number is greater than 1000')
    } else if (num > 100) {
        console.log('Number is greater than 100')
    } else if (num > 10) {
        console.log('Number is greater than 10')
    } else {
        console.log('Number is less than or equal to 10')
    }
}

test()
