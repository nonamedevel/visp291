function test() {
    const availableColors = new Map([
        ['green', {name: 'green', order: 2}],
        ['red', {name: 'red', order: 1}],
        ['blue', {name: 'blue', order: 3}],
    ])
    const objArr = [...availableColors.values()]
    console.log(objArr)
    objArr.sort(function(objA, objB) {
        return objA.order - objB.order
        // return objB.order - objA.order
    })
    objArr.sort((objA, objB) => objA.order - objB.order)
    console.log(objArr)
}

test()
