// setTimeout(function() {
//     const button = document.createElement('button')
//     button.textContent = 'Remove'
//     document.body.append(button)
//     button.addEventListener('click', function() {
//         button.remove()
//     })
// }, 3000)

setTimeout(function() {
    console.log('Hello there!')
}, 3000)

// setInterval()
