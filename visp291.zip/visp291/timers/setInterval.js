function test1() {
    setInterval(function() {
        console.log('Hello there!')
    }, 1000)
}

function test() {
    setInterval(function() {
        const button = document.createElement('button')
        button.textContent = 'Remove'
        document.body.append(button)
        button.addEventListener('click', function() {
            button.remove()
        })
    }, 1000)
}

test()
