function test1() {
    let singleQuote = 'Single quote'
    let doubleQuote = "Double quote"
    let backtick = `Backtick (backquote)`
    console.log(singleQuote)
    console.log(doubleQuote)
    console.log(backtick)
}

function test() {
    function func() {}
    console.log(func)
    console.log(func + '!')
    console.log('--------------------')
    func.toString = () => 'hello'
    console.log(func)
    console.log(func + '!')
}

test()
