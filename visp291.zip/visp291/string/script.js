function test() {
    let singleQuote = 'Single quote'
    let doubleQuote = "Double quote"
    let backtick = `Backtick (backquote)`
    console.log(singleQuote)
    console.log(doubleQuote)
    console.log(backtick)
}

test()
