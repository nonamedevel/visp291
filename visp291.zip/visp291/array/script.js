function test1() {
    const user1 = 'John'
    const user2 = 'Mary'
    const user3 = 'Vasya'
    console.log(user1)
    console.log(user2)
    console.log(user3)
}

function test1() {
    const users = [
        'John',
        'Mary',
        'Vasya',        
    ]
    console.log(users[0])
    console.log(users[1])
    console.log(users[2])
}

function test() {
    const users = [
        'John',
        'Mary',
        // 'Vasya',        
    ]
    console.log(users.length)
}

function test1() {
    const users = [
        'John',
        'Mary',
        'Vasya',
        'Max',
    ]
    // for (let i = 0; i < users.length; i++) {
    //     console.log(users[i])
    // }
    for (const user of users) {
        console.log(user)
    }
}

function test1() {
    const users = []
    users.push('John')
    users.push('Mary')
    users.push('Vasya')
    users.push('Max')
    for (const user of users) {
        console.log(user)
    }
}

test()