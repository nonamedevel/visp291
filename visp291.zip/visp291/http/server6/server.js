const http = require('node:http')
const fs = require('node:fs')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]

const server = http.createServer((req, res) => {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        fs.readFile('C:/visp291/http/server6/index.html', (err, data) => {
            res.writeHead(200, { 'Content-Type': 'text/html' })
            res.end(data)
        })
    } else if (req.url === '/about') {
        fs.readFile('C:/visp291/http/server6/about.html', (err, data) => {
            res.writeHead(200, { 'Content-Type': 'text/html' })
            res.end(data)
        })
    } else if (req.url === '/contacts') {
        fs.readFile('C:/visp291/http/server6/contacts.html', (err, data) => {
            res.writeHead(200, { 'Content-Type': 'text/html' })
            res.end(data)
        })
    } else {
        fs.readFile('C:/visp291/http/server6/404.html', (err, data) => {
            res.writeHead(404, { 'Content-Type': 'text/html' })
            res.end(data)
        })
    }
})

server.listen(8000)