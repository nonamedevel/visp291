const http = require('node:http')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]

const server = http.createServer((req, res) => {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({
        data: 'Hello World!',
    }))
})

server.listen(8000)