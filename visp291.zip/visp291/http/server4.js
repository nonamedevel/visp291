const http = require('node:http')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]

const server = http.createServer((req, res) => {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' })
        res.end('<h1>Main page</h1>')
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' })
        res.end('<h1>404 Not found</h1>')
    }
})

server.listen(8000)