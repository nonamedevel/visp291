const http = require('node:http')
const fs = require('node:fs')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]

function sendFile(res, fileName, statusCode = 200) {
    fs.readFile('C:/visp291/http/server7/' + fileName, (err, data) => {
        res.writeHead(statusCode, { 'Content-Type': 'text/html' })
        res.end(data)
    })
}

const server = http.createServer((req, res) => {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        sendFile(res, 'index.html')
    } else if (req.url === '/about') {
        sendFile(res, 'about.html')
    } else if (req.url === '/contacts') {
        sendFile(res, 'contacts.html')
    } else {
        sendFile(res, '404.html', 404)
    }
})

server.listen(8000)