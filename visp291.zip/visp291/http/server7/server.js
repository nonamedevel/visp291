const http = require('node:http')
const fs = require('node:fs')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
]

const contentTypes = {
    html: 'text/html',
    ico: 'image/x-icon',
    json: 'application/json',
}

function sendFile(res, fileName, statusCode = 200) {
    fs.readFile('C:/visp291/http/server7/' + fileName, (err, data) => {
        const fileExtension = fileName.split('.').slice(-1)[0]
        const contentType = contentTypes[fileExtension]
        res.writeHead(statusCode, { 'Content-Type': contentType })
        res.end(data)
    })
}

const server = http.createServer((req, res) => {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        sendFile(res, 'index.html')

    } else if (req.url === '/about') {
        sendFile(res, 'about.html')

    } else if (req.url === '/contacts') {
        sendFile(res, 'contacts.html')

    } else if (req.url === '/favicon.ico') {
        sendFile(res, 'favicon.ico')

    } else if (req.url === '/products') {
        sendFile(res, 'products.html')

    } else if (req.url === '/products_list') {
        sendFile(res, 'products.json')

    } else {
        sendFile(res, '404.html', 404)
    }
})

server.listen(8000)