
function test() {
    class User {
        static userCount = 0
        constructor(name, age, city) {
            this.name = name
            this.age = Number(age)
            this.city = city
            User.userCount++
        }
        static parseInfo1(str) {
            const arr = str.split(' ')
            return new User(arr[0], Number(arr[1]), arr[2])
            console.log(arr)
        }
        static parseInfo1(str) {
            const [name, age, city] = str.split(' ')
            return new User(name, Number(age), city)
            console.log(arr)
        }
        static parseInfo(str) {
            const arr = str.split(' ')
            return new User(...arr)
            console.log(arr)
        }
        printInfo() {
            console.log(this.name, this.age, this.city)
        }
        addYears(years = 1) {
            this.age += years
            return this
        }
    }
    User.parseInfo('Vasya 30 Ufa').printInfo()
    User.parseInfo('Vasya 30 Ufa').addYears().printInfo()
    User.parseInfo('Vasya 30 Ufa').addYears(5).printInfo()
    console.log(User.userCount)
}

test()