function test1() {
    class User {
        constructor(name, age, city) {
            this.name = name
            this.age = age
            this.city = city
        }
        printInfo() {
            if (this.name && this.age && this.city) {
                console.log(this.name, this.age, this.city)
            }
        }
    }
    const user1 = new User('Vasya', 31, 'Moscow')
    user1.printInfo()
    const user2 = new User('Masha', 21, 'Moscow')
    user2.printInfo()
}

function test1() {
    class User {
        constructor(name = 'User', age = 99, city = 'Moscow') {
            this.name = name
            this.age = age
            this.city = city
        }
        printInfo() {
            if (this.name && this.age && this.city) {
                console.log(this.name, this.age, this.city)
            }
        }
    }
    const user1 = new User('Vasya', undefined, 'Krasnogorsk')
    user1.printInfo()
    const user2 = new User('Masha', 21)
    user2.printInfo()
    const user3 = new User()
    user3.printInfo()
}

function test() {
    class User {
        constructor(opts = {}) {
            this.name = opts.name || 'User'
            this.age = opts.age || 99
            this.city = opts.city || 'Moscow'
        }
        printInfo() {
            if (this.name && this.age && this.city) {
                console.log(this.name, this.age, this.city)
            }
        }
    }

    const user1 = new User({
        city: 'Krasnogorsk',
        name: 'Vasya',
    })
    user1.printInfo()
    
    const user2 = new User({
        name: 'Masha',
        age: 21,
    })
    user2.printInfo()
    
    const user3 = new User()
    user3.printInfo()
}

test()