function test1() {
    const name = 'Vasya'
    const age = 30
    const city = 'Moscow'
    console.log(name, age, city)
}

function test1() {
    const user = {
        name: 'Vasya',
        age: 30,
        city: 'Moscow',
    }
    console.log(user.name, user.age, user.city)
}

function test1() {
    const user = {
        name: 'Vasya',
        age: 30,
        city: 'Moscow',
        printInfo() {
            console.log(this.name, this.age, this.city)
        }
    }
    user.printInfo()
}

function test1() {
    const user = {
        printInfo() {
            console.log(this.name, this.age, this.city)
        }
    }
    user.printInfo()
    
    user.name = 'Vasya'
    user.age = 30
    user.city = 'Moscow'
    user.printInfo()
}

function test() {
    const user = {
        printInfo() {
            if (this.name && this.age && this.city) {
                console.log(this.name, this.age, this.city)
            }
        }
    }
    user.printInfo()
    
    user.name = 'Vasya'
    user.age = 30
    user.city = 'Moscow'
    user.printInfo()
}

test()