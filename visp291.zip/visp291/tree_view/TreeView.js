class TreeView extends Widget {
    constructor(files) {
        super()
        this.marginIncrement = 30
        this.files = files
        this.container = document.querySelector('.tree_view')
        this.elemToPathMap = new Map()
        this.dirElemToIsCollapsed = new Map()
        this.populate(this.files)
        this.container.addEventListener('click', this.onClick.bind(this))
    }
    onClick(event) {
        if (event.target.classList.contains('item')) {
            const itemPath = this.elemToPathMap.get(event.target)
            this.emit('itemSelected', itemPath)
        }
        if (event.target.classList.contains('folder_item')) {
            const isCollapsed = this.dirElemToIsCollapsed.get(event.target)
            if (isCollapsed) {
                this.showChildren(event.target)
            } else {
                this.hideChildren(event.target)
            }
            this.dirElemToIsCollapsed.set(event.target, !isCollapsed)
        }
    }
    showChildren(dirElem) {
        const parentMargin = parseInt(dirElem.style.marginLeft)
        const targetMargin = parentMargin + this.marginIncrement
        let row = dirElem.nextElementSibling
        let currentMargin = parseInt(row.style.marginLeft)
        while (row && currentMargin >= targetMargin) {
            row.classList.remove('hidden')
            console.log(row)
            row = row.nextElementSibling
            currentMargin = parseInt(row.style.marginLeft)
        }
    }
    hideChildren(dirElem) {
        const parentMargin = parseInt(dirElem.style.marginLeft)
        const targetMargin = parentMargin + this.marginIncrement
        let row = dirElem.nextElementSibling
        let currentMargin = parseInt(row.style.marginLeft)
        while (row && currentMargin >= targetMargin) {
            row.classList.add('hidden')
            row = row.nextElementSibling
            currentMargin = parseInt(row.style.marginLeft)
        }
    }
    populate(array, level = 0, path = []) {
        for (const item of array) {
            const row = document.createElement('div')
            row.style.marginLeft = (this.marginIncrement * level) + 'px'
            row.textContent = item.name
            this.container.append(row)
            let newPath
            if (item.children) {
                newPath = [...path, {
                    name: item.name,
                    type: 'folder_item',
                }]
                row.classList.add('folder_item')
                this.dirElemToIsCollapsed.set(row, false)
            } else {
                newPath = [...path, {
                    name: item.name,
                    type: 'file_item',
                }]
                row.classList.add('file_item')
            }
            if (item.children) {
                this.populate(item.children, level + 1, newPath)
            }
            this.elemToPathMap.set(row, newPath)
            row.classList.add('item')
        }
    }
}
