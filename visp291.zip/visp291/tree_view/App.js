class App {
    constructor(files) {
        this.treeView = new TreeView(files)
        this.treeView.on('itemSelected', this.onItemSelected.bind(this))

        this.filePath = new FilePath()
        this.filePath.container.textContent = 'No selection'
    }
    onItemSelected(item) {
        this.filePath.setText(item)
    }
}
