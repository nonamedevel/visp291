class Widget {
    constructor() {
        this.handlers = {}
    }
    on(event, handler) {
        this.handlers[event] = handler
    }
    emit(event, ...args) {
        if (this.handlers[event]) {
            this.handlers[event](...args)
        }
    }
}
