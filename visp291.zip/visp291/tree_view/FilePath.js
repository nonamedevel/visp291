class FilePath extends Widget {
    constructor() {
        super()
        this.container = document.querySelector('.file_path')
    }
    setText(arr) {
        this.container.textContent = ''
        for (const item of arr) {
            const pathSegment = document.createElement('div')
            pathSegment.classList.add('segment')
            pathSegment.classList.add(item.type)
            pathSegment.textContent = item.name
            this.container.append(pathSegment)
            if (item !== arr[arr.length - 1]) {
                const slashElem = document.createElement('div')
                slashElem.textContent = '/'
                this.container.append(slashElem)
            }
        }
    }
}
