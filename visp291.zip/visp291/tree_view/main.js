const files = [
    {name: 'dir1', children: []},
    {name: 'dir2', children: [
        {name: 'dir3', children: [
            {name: 'example7.txt'},
            {name: 'example8.txt'},
            {name: 'example9.txt'},
        ]},
        {name: 'example10.txt'},
    ]},
    {name: 'dir4', children: [
        {name: 'example1.txt'},
        {name: 'example2.txt'},
        {name: 'example6.txt'},
    ]},
    {name: 'dir5', children: [
        {name: 'example3.txt'},
    ]},
    {name: 'example4.txt'},
    {name: 'example5.txt'},
]

const app = new App(files)
