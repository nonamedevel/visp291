const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })

const socketToColor = new Map()
const availableColors = new Set(['red', 'green', 'blue'])

wss.on('connection', (ws) => {
    socketToColor.set(ws, null)
    console.log(socketToColor.size)
    ws.on('error', console.error)

    ws.on('close', () => {
        console.log('close event')
        const color = socketToColor.get(ws)
        socketToColor.delete(ws)
        if (color) {
            availableColors.add(color)
            ws.send(JSON.stringify({
                type: 'available_colors',
                value: [...availableColors],
            }))
        }
    })

    ws.on('message', (data) => {
        const messageObj = JSON.parse(data)
        if (messageObj.type === 'select_color') {
            socketToColor.set(ws, messageObj.value)
            availableColors.delete(messageObj.value)
        } else {
            console.log('Unknown message type')
        }
    })

    ws.send(JSON.stringify({
        type: 'available_colors',
        value: [...availableColors],
    }))
})
