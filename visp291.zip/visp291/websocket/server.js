/*
    Проблема: При выборе цвета другим пользователем,
    у текущего пользователя обновляются кнопки,
    при этом кнопка с выбранным цветом перестает отображаться
    (так как она уже занята текущим пользователем).
    Однако с точки зрения UX, эту кнопку все-таки имеет смысл отображать.

    Решение: Отправлять клиенту не массив строк с названиями доступных цветов,
    а массив объектов. Текущий цвет должен быть помечен (selected: true).
*/
const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })

const example = [
    {name: 'red', order: 1, selected: true},
    {name: 'green', order: 2, selected: false},
    {name: 'blue', order: 3, selected: false},
]

const socketToColor = new Map()
const availableColors = new Map([
    ['red', {name: 'red', order: 1}],
    ['green', {name: 'green', order: 2}],
    ['blue', {name: 'blue', order: 3}],
])

wss.on('connection', (ws) => {
    socketToColor.set(ws, null)
    console.log(socketToColor.size)
    ws.on('error', console.error)

    ws.on('close', () => {
        console.log('close event')
        const colorObj = socketToColor.get(ws)
        socketToColor.delete(ws)
        if (colorObj) {
            availableColors.set(colorObj.name, colorObj)
            sendAvailableColors(ws)
        }
    })

    ws.on('message', (data) => {
        const messageObj = JSON.parse(data)
        if (messageObj.type === 'select_color') {
            const colorName = messageObj.value
            let colorObj = socketToColor.get(ws)
            if (colorObj) {
                availableColors.set(colorObj.name, colorObj)
                sendAvailableColors(ws)
            }
            colorObj = availableColors.get(colorName)
            socketToColor.set(ws, colorObj)
            availableColors.delete(colorName)
        } else {
            console.log('Unknown message type')
        }
    })

    sendAvailableColors()
})

function sendAvailableColors(currentSocket) {
    let colors = [...availableColors.values()]
    colors.sort((objA, objB) => objA.order - objB.order)
    colors = colors.map(obj => obj.name)
    const msg = JSON.stringify({
        type: 'available_colors',
        value: colors,
    })
    for (const socket of socketToColor.keys()) {
        if (socket === currentSocket) {
            continue
        }
        socket.send(msg)
    }
}
