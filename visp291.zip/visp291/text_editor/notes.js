/*

Interesting commands:

notifications.focusToasts

notification.acceptPrimaryAction


*/