const notificationContainer = document.createElement('div')
notificationContainer.classList.add('notification_container')
document.body.append(notificationContainer)

const topRow = document.createElement('div')
topRow.classList.add('top_row')
notificationContainer.append(topRow)

const infoIcon = document.createElement('div')
infoIcon.classList.add('info_icon')
infoIcon.textContent = 'i'
topRow.append(infoIcon)

const messageBox = document.createElement('div')
messageBox.classList.add('message_box')
messageBox.textContent = 'Do you want to install the recommended extensions from Microsoft, GitHub and others for this repository?'
topRow.append(messageBox)

const buttonBox = document.createElement('div')
buttonBox.classList.add('button_box')
topRow.append(buttonBox)

const settingsButton = document.createElement('button')
settingsButton.classList.add('settings')
settingsButton.textContent = 'S'
buttonBox.append(settingsButton)
settingsButton.addEventListener('click', hideWidget)

const closeButton = document.createElement('button')
closeButton.classList.add('close')
closeButton.textContent = 'C'
buttonBox.append(closeButton)
closeButton.addEventListener('click', hideWidget)

const bottomRow = document.createElement('div')
bottomRow.classList.add('bottom_row')
notificationContainer.append(bottomRow)

const installButton = document.createElement('button')
installButton.classList.add('install')
installButton.textContent = 'Install'
bottomRow.append(installButton)
installButton.addEventListener('click', hideWidget)

const showRecommendationsButton = document.createElement('button')
showRecommendationsButton.classList.add('show_recommendations')
showRecommendationsButton.textContent = 'Show Recommendations'
bottomRow.append(showRecommendationsButton)
showRecommendationsButton.addEventListener('click', hideWidget)

function hideWidget() {
    notificationContainer.style.display = 'none'
}
