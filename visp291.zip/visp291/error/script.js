try {
    // throw new Error('This is an error')
    document
    console.log('frontend')
} catch(err) {
    if (err.name === 'ReferenceError') {
        console.log('backend')
    } else {
        throw err
    }
}
console.log('The End')